```
     __                    _         _             _ __  
    / _|  __ _     ___    | |_    __| |    ___    | '_ \ 
   |  _| / _` |   (_-<    |  _|  / _` |   / -_)   | .__/ 
  _|_|_  \__,_|   /__/_   _\__|  \__,_|   \___|   |_|__  
_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""|_|"""""| 
"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-'"`-0-0-' 
```

# fastdep

> fastdep is a framework for fast integration dependencies.

[GitHub](https://github.com/louislivi/fastdep)
[Quick Start](/en/README.md)